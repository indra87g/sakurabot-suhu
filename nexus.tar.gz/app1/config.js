// GANTI sesuai data kamu
module.exports = {
  TOKEN: "8377009031:AAE3KuQaII0OQeTkG6BXKW5i3LDyY-eNR9A",
  CHANNEL_ID: -1003033136386, // Channel premium
  OWNER_ID: 6362056930,       // ID owner
  OWNER_LINK: "https://t.me/indra87g30spki",
  DEV_LINK: "https://t.me/indra87g30spki",
  INFO_OWNER_LINK: "https://t.me/link_videy_terbaruviral",
  PREMIUM_JOIN_LINK: "https://t.me/link_videy_terbaruviral"
};